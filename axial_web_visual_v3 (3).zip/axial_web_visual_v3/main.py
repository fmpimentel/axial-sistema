from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Optional
import sqlite3
from pathlib import Path
from datetime import datetime
import hashlib
import io
import base64
import shutil
import uuid
import qrcode
import smtplib
from email.message import EmailMessage

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'database.db'
EXPORTS_DIR = BASE_DIR / 'exports'
TMP_DIR = BASE_DIR / 'tmp'
STATIC_DIR = BASE_DIR / 'static'
SIGNATURES_DIR = STATIC_DIR / 'signatures'

for p in [EXPORTS_DIR, TMP_DIR, SIGNATURES_DIR]:
    p.mkdir(parents=True, exist_ok=True)

app = FastAPI(title='AXIAL Sistema V3')
app.mount('/static', StaticFiles(directory=str(STATIC_DIR)), name='static')
templates = Jinja2Templates(directory=str(BASE_DIR / 'templates'))

ROLE_LABELS = {'admin': 'Administrador', 'engenheiro': 'Engenheiro', 'tecnico': 'Técnico'}


def hash_password(raw: str) -> str:
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'tecnico',
        full_name TEXT,
        email TEXT,
        signature_path TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS afericoes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT NOT NULL,
        equipamento TEXT NOT NULL,
        serie TEXT,
        indice_nominal REAL NOT NULL,
        media_obtida REAL NOT NULL,
        fator REAL NOT NULL,
        status TEXT NOT NULL,
        responsavel TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS ensaios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT NOT NULL,
        cliente TEXT NOT NULL,
        obra TEXT NOT NULL,
        elemento TEXT,
        equipamento TEXT,
        responsavel TEXT,
        indice_medio REAL NOT NULL,
        fator_afericao REAL NOT NULL,
        indice_corrigido REAL NOT NULL,
        fck_estimado REAL NOT NULL,
        cv REAL NOT NULL,
        status TEXT NOT NULL,
        afericao_status TEXT,
        laudo_hash TEXT,
        pdf_path TEXT,
        cloud_path TEXT,
        created_by TEXT,
        email_sent_at TEXT
    )
    """)
    cur.execute("SELECT COUNT(*) AS n FROM users")
    if cur.fetchone()['n'] == 0:
        now = datetime.now().isoformat(timespec='seconds')
        users = [
            ('admin', hash_password('1234'), 'admin', 'Administrador AXIAL', 'admin@axial.local', '/static/signatures/signature_default.png', now),
            ('engenharia', hash_password('1234'), 'engenheiro', 'Engenharia AXIAL', 'engenharia@axial.local', '/static/signatures/signature_default.png', now),
            ('tecnico', hash_password('1234'), 'tecnico', 'Técnico AXIAL', 'tecnico@axial.local', '/static/signatures/signature_default.png', now),
        ]
        cur.executemany(
            "INSERT INTO users (username, password_hash, role, full_name, email, signature_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            users,
        )

    default_settings = {
        'company_name': 'AXIAL Tecnologia para Construção Civil',
        'cloud_provider': 'local',
        'cloud_base_path': str(EXPORTS_DIR),
        'smtp_host': '',
        'smtp_port': '587',
        'smtp_user': '',
        'smtp_password': '',
        'smtp_from': '',
        'smtp_use_tls': '1'
    }
    for k, v in default_settings.items():
        cur.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))
    conn.commit()
    conn.close()


init_db()


class EnsaioIn(BaseModel):
    cliente: str
    obra: str
    elemento: Optional[str] = ''
    equipamento: Optional[str] = ''
    responsavel: Optional[str] = ''
    indice_medio: float
    fator_afericao: float = 1.0
    cv: float = 0.0


class AfericaoIn(BaseModel):
    data: str
    equipamento: str
    serie: Optional[str] = ''
    indice_nominal: float = 80.0
    media_obtida: float = 80.0
    responsavel: Optional[str] = ''


def get_settings_map():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT key, value FROM settings")
    data = {r['key']: r['value'] for r in cur.fetchall()}
    conn.close()
    return data


def calc_fck(indice_corrigido: float) -> float:
    return round(max(0.0, 1.6 * indice_corrigido - 15.0), 2)


def calc_status(fck: float, cv: float) -> str:
    if cv > 15:
        return 'Atenção'
    if fck >= 25:
        return 'Conforme'
    return 'Não conforme'


def get_current_user(request: Request):
    username = request.cookies.get('axial_user')
    if not username:
        return None
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM users WHERE username = ? AND is_active = 1', (username,))
    user = cur.fetchone()
    conn.close()
    return user


def require_login(request: Request):
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail='Não autenticado')
    return user


def require_role(request: Request, roles):
    user = require_login(request)
    if user['role'] not in roles:
        raise HTTPException(status_code=403, detail='Sem permissão')
    return user


def compute_record_hash(record: sqlite3.Row) -> str:
    raw = '|'.join([
        str(record['id']), str(record['data']), str(record['cliente']), str(record['obra']),
        str(record['elemento']), str(record['equipamento']), str(record['responsavel']),
        str(record['indice_medio']), str(record['fator_afericao']), str(record['indice_corrigido']),
        str(record['fck_estimado']), str(record['cv']), str(record['status']), str(record['afericao_status']),
        str(record['created_by'])
    ])
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def safe_folder_name(text: str) -> str:
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_ "
    clean = ''.join(c for c in text if c in allowed).strip().replace(' ', '_')
    return clean or 'sem_nome'


@app.get('/', response_class=HTMLResponse)
def home(request: Request):
    if request.cookies.get('axial_user'):
        return RedirectResponse(url='/dashboard', status_code=303)
    return templates.TemplateResponse('login.html', {'request': request, 'error': None})


@app.post('/login', response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM users WHERE username = ? AND is_active = 1', (username,))
    user = cur.fetchone()
    conn.close()
    if not user or user['password_hash'] != hash_password(password):
        return templates.TemplateResponse('login.html', {'request': request, 'error': 'Usuário ou senha inválidos.'}, status_code=401)
    response = RedirectResponse(url='/dashboard', status_code=303)
    response.set_cookie('axial_user', username, httponly=False)
    return response


@app.get('/logout')
def logout():
    response = RedirectResponse(url='/', status_code=303)
    response.delete_cookie('axial_user')
    return response


@app.get('/dashboard', response_class=HTMLResponse)
def dashboard(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)

    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT COUNT(*) AS total FROM ensaios')
    total_ensaios = cur.fetchone()['total']
    cur.execute('SELECT COUNT(DISTINCT obra) AS total FROM ensaios')
    total_obras = cur.fetchone()['total']
    cur.execute('SELECT ROUND(COALESCE(AVG(fck_estimado), 0), 2) AS media FROM ensaios')
    media_fck = cur.fetchone()['media']
    cur.execute("SELECT COUNT(*) AS total FROM ensaios WHERE status = 'Não conforme'")
    nao_conformes = cur.fetchone()['total']
    cur.execute('SELECT ROUND(COALESCE(AVG(cv), 0), 2) AS media FROM ensaios')
    media_cv = cur.fetchone()['media']
    cur.execute('SELECT * FROM ensaios ORDER BY id DESC LIMIT 8')
    ensaios = cur.fetchall()
    cur.execute('SELECT * FROM afericoes ORDER BY id DESC LIMIT 5')
    afericoes = cur.fetchall()
    cur.execute('SELECT COUNT(*) AS total FROM users WHERE is_active = 1')
    total_usuarios = cur.fetchone()['total']
    conn.close()
    settings = get_settings_map()
    return templates.TemplateResponse('dashboard.html', {
        'request': request,
        'user': user,
        'role_labels': ROLE_LABELS,
        'total_ensaios': total_ensaios,
        'total_obras': total_obras,
        'media_fck': media_fck,
        'nao_conformes': nao_conformes,
        'media_cv': media_cv,
        'total_usuarios': total_usuarios,
        'ensaios': ensaios,
        'afericoes': afericoes,
        'cloud_provider': settings.get('cloud_provider', 'local'),
    })


@app.get('/api/dashboard')
def api_dashboard(request: Request):
    require_login(request)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT substr(data,1,7) AS mes, COUNT(*) AS total
        FROM ensaios
        GROUP BY substr(data,1,7)
        ORDER BY mes
    """)
    por_mes = [dict(r) for r in cur.fetchall()]
    cur.execute("""
        SELECT obra, ROUND(AVG(fck_estimado), 2) AS fck
        FROM ensaios
        GROUP BY obra
        ORDER BY fck DESC
        LIMIT 10
    """)
    por_obra = [dict(r) for r in cur.fetchall()]
    cur.execute("""
        SELECT status, COUNT(*) AS total
        FROM ensaios
        GROUP BY status
        ORDER BY total DESC
    """)
    por_status = [dict(r) for r in cur.fetchall()]
    conn.close()
    return {'por_mes': por_mes, 'por_obra': por_obra, 'por_status': por_status}


@app.get('/ensaio', response_class=HTMLResponse)
def ensaio_form(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT fator, status, equipamento FROM afericoes ORDER BY id DESC LIMIT 1')
    ultima = cur.fetchone()
    conn.close()
    return templates.TemplateResponse('ensaio.html', {'request': request, 'user': user, 'role_labels': ROLE_LABELS, 'ultima_afericao': ultima})


@app.post('/ensaio')
def salvar_ensaio(request: Request, payload: EnsaioIn):
    user = require_role(request, ['admin', 'engenheiro', 'tecnico'])
    indice_corrigido = round(payload.indice_medio * payload.fator_afericao, 2)
    fck = calc_fck(indice_corrigido)
    status = calc_status(fck, payload.cv)
    data = datetime.now().strftime('%Y-%m-%d %H:%M')

    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT status FROM afericoes ORDER BY id DESC LIMIT 1')
    ultima_afericao = cur.fetchone()
    afericao_status = ultima_afericao['status'] if ultima_afericao else 'Sem aferição'

    cur.execute('''
    INSERT INTO ensaios (
        data, cliente, obra, elemento, equipamento, responsavel,
        indice_medio, fator_afericao, indice_corrigido, fck_estimado, cv, status,
        afericao_status, laudo_hash, pdf_path, cloud_path, created_by, email_sent_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data, payload.cliente, payload.obra, payload.elemento, payload.equipamento, payload.responsavel,
        payload.indice_medio, payload.fator_afericao, indice_corrigido, fck, payload.cv, status,
        afericao_status, '', '', '', user['username'], ''
    ))
    ensaio_id = cur.lastrowid
    cur.execute('SELECT * FROM ensaios WHERE id = ?', (ensaio_id,))
    record = cur.fetchone()
    record_hash = compute_record_hash(record)
    cur.execute('UPDATE ensaios SET laudo_hash = ? WHERE id = ?', (record_hash, ensaio_id))
    conn.commit()
    conn.close()
    return {
        'id': ensaio_id,
        'indice_corrigido': indice_corrigido,
        'fck_estimado': fck,
        'status': status,
        'laudo_hash': record_hash,
        'mensagem': 'Ensaio salvo com sucesso.'
    }


@app.get('/afericao', response_class=HTMLResponse)
def afericao_form(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)
    return templates.TemplateResponse('afericao.html', {'request': request, 'user': user, 'role_labels': ROLE_LABELS})


@app.post('/afericao')
def salvar_afericao(request: Request, payload: AfericaoIn):
    require_role(request, ['admin', 'engenheiro'])
    fator = round(payload.indice_nominal / payload.media_obtida, 4) if payload.media_obtida else 1.0
    status = 'Aprovado' if abs(payload.media_obtida - payload.indice_nominal) <= 2 else 'Reprovado'
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('''
    INSERT INTO afericoes (data, equipamento, serie, indice_nominal, media_obtida, fator, status, responsavel)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (payload.data, payload.equipamento, payload.serie, payload.indice_nominal, payload.media_obtida, fator, status, payload.responsavel))
    conn.commit()
    afericao_id = cur.lastrowid
    conn.close()
    return {
        'id': afericao_id,
        'fator': fator,
        'status': status,
        'mensagem': 'Aferição registrada com sucesso.'
    }


@app.get('/laudo/{ensaio_id}', response_class=HTMLResponse)
def visualizar_laudo(request: Request, ensaio_id: int):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)

    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM ensaios WHERE id = ?', (ensaio_id,))
    ensaio = cur.fetchone()
    if not ensaio:
        conn.close()
        raise HTTPException(status_code=404, detail='Ensaio não encontrado')
    cur.execute('SELECT * FROM afericoes ORDER BY id DESC LIMIT 1')
    afericao = cur.fetchone()
    conn.close()

    qr_data = request.url_for('visualizar_laudo', ensaio_id=ensaio_id)
    qr_img = qrcode.make(str(qr_data))
    buf = io.BytesIO()
    qr_img.save(buf, format='PNG')
    qr_b64 = base64.b64encode(buf.getvalue()).decode('utf-8')

    return templates.TemplateResponse('laudo.html', {
        'request': request,
        'user': user,
        'role_labels': ROLE_LABELS,
        'ensaio': ensaio,
        'afericao': afericao,
        'qr_b64': qr_b64,
        'qr_data': qr_data,
        'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M'),
    })


def make_qr_temp(path_text: str) -> Path:
    qr_img = qrcode.make(path_text)
    fname = TMP_DIR / f'qr_{uuid.uuid4().hex}.png'
    qr_img.save(fname)
    return fname


def build_pdf(ensaio: sqlite3.Row, afericao: Optional[sqlite3.Row], user: sqlite3.Row, base_url: str) -> Path:
    file_name = f'laudo_ensaio_{ensaio["id"]}.pdf'
    pdf_path = EXPORTS_DIR / file_name
    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=18*mm)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph('<b>AXIAL Tecnologia para Construção Civil</b>', styles['Title']))
    story.append(Paragraph('Laudo de Esclerometria - Versão 3', styles['Heading2']))
    story.append(Spacer(1, 6))

    meta = [
        ['Laudo', f'Ensaio #{ensaio["id"]}'],
        ['Data do ensaio', ensaio['data']],
        ['Cliente', ensaio['cliente']],
        ['Obra', ensaio['obra']],
        ['Elemento', ensaio['elemento'] or '-'],
        ['Equipamento', ensaio['equipamento'] or '-'],
        ['Responsável', ensaio['responsavel'] or '-'],
        ['Criado por', ensaio['created_by'] or '-'],
    ]
    tbl = Table(meta, colWidths=[42*mm, 120*mm])
    tbl.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.6, colors.grey),
        ('INNERGRID', (0,0), (-1,-1), 0.4, colors.lightgrey),
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('PADDING', (0,0), (-1,-1), 5),
    ]))
    story.extend([tbl, Spacer(1, 10)])

    resultados = [
        ['Índice médio (I)', f'{ensaio["indice_medio"]:.2f}'],
        ['Fator de aferição', f'{ensaio["fator_afericao"]:.4f}'],
        ['Índice corrigido (Ie)', f'{ensaio["indice_corrigido"]:.2f}'],
        ['fck estimado', f'{ensaio["fck_estimado"]:.2f} MPa'],
        ['CV', f'{ensaio["cv"]:.2f} %'],
        ['Status', ensaio['status']],
        ['Status da aferição', ensaio['afericao_status'] or '-'],
    ]
    rt = Table(resultados, colWidths=[55*mm, 107*mm])
    rt.setStyle(TableStyle([
        ('BOX', (0,0), (-1,-1), 0.6, colors.grey),
        ('INNERGRID', (0,0), (-1,-1), 0.4, colors.lightgrey),
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('PADDING', (0,0), (-1,-1), 5),
    ]))
    story.extend([Paragraph('<b>Resultados do ensaio</b>', styles['Heading3']), rt, Spacer(1, 10)])

    if afericao:
        af = [
            ['Data da última aferição', afericao['data']],
            ['Equipamento aferido', afericao['equipamento']],
            ['Série', afericao['serie'] or '-'],
            ['Índice nominal', f'{afericao["indice_nominal"]:.2f}'],
            ['Média obtida', f'{afericao["media_obtida"]:.2f}'],
            ['Fator', f'{afericao["fator"]:.4f}'],
            ['Situação', afericao['status']],
        ]
        at = Table(af, colWidths=[55*mm, 107*mm])
        at.setStyle(TableStyle([
            ('BOX', (0,0), (-1,-1), 0.6, colors.grey),
            ('INNERGRID', (0,0), (-1,-1), 0.4, colors.lightgrey),
            ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
            ('PADDING', (0,0), (-1,-1), 5),
        ]))
        story.extend([Paragraph('<b>Rastreabilidade da aferição</b>', styles['Heading3']), at, Spacer(1, 10)])

    qr_url = f'{base_url.rstrip("/")}/laudo/{ensaio["id"]}'
    qr_path = make_qr_temp(qr_url)
    qr_img = Image(str(qr_path), width=35*mm, height=35*mm)

    hash_short = ensaio['laudo_hash'][:16] if ensaio['laudo_hash'] else ''
    signature_lines = [
        f'Assinatura eletrônica visual: {user["full_name"] or user["username"]}',
        f'Gerado em: {datetime.now().strftime("%d/%m/%Y %H:%M")}',
        f'Hash SHA-256: {hash_short}...',
        f'Arquivo local: {ensaio["pdf_path"] or "-"}',
        f'Armazenamento: {ensaio["cloud_path"] or "-"}',
        'Observação: esta assinatura é eletrônica visual e não substitui certificado ICP-Brasil.'
    ]
    signature_para = Paragraph('<br/>'.join(signature_lines), styles['BodyText'])

    sign_path = BASE_DIR / user['signature_path'].lstrip('/') if user['signature_path'] else None
    sign_img = None
    if sign_path and sign_path.exists():
        sign_img = Image(str(sign_path), width=45*mm, height=18*mm)

    sign_table_data = [[qr_img, signature_para]]
    if sign_img:
        sign_table_data.append([Paragraph('<b>Assinatura</b>', styles['BodyText']), sign_img])

    sign_tbl = Table(sign_table_data, colWidths=[42*mm, 120*mm])
    sign_tbl.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BOX', (0,0), (-1,-1), 0.6, colors.grey),
        ('INNERGRID', (0,0), (-1,-1), 0.4, colors.lightgrey),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.extend([Paragraph('<b>Validação e assinatura</b>', styles['Heading3']), sign_tbl])

    doc.build(story)
    qr_path.unlink(missing_ok=True)
    return pdf_path


def export_to_cloud(pdf_path: Path, ensaio: sqlite3.Row) -> str:
    settings = get_settings_map()
    provider = settings.get('cloud_provider', 'local')
    base_path = settings.get('cloud_base_path', str(EXPORTS_DIR))
    target_root = Path(base_path)
    target_dir = target_root / safe_folder_name(ensaio['cliente']) / safe_folder_name(ensaio['obra'])
    target_dir.mkdir(parents=True, exist_ok=True)
    target_file = target_dir / pdf_path.name
    shutil.copy2(pdf_path, target_file)
    return f'{provider}:{target_file}'


def get_or_build_pdf(request: Request, ensaio_id: int):
    user = require_login(request)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM ensaios WHERE id = ?', (ensaio_id,))
    ensaio = cur.fetchone()
    if not ensaio:
        conn.close()
        raise HTTPException(status_code=404, detail='Ensaio não encontrado')
    cur.execute('SELECT * FROM afericoes ORDER BY id DESC LIMIT 1')
    afericao = cur.fetchone()
    conn.close()

    pdf_path = build_pdf(ensaio, afericao, user, str(request.base_url))
    cloud_path = export_to_cloud(pdf_path, ensaio)

    conn = get_conn()
    cur = conn.cursor()
    rel_local = str(pdf_path.relative_to(BASE_DIR))
    cur.execute('UPDATE ensaios SET pdf_path = ?, cloud_path = ? WHERE id = ?', (rel_local, cloud_path, ensaio_id))
    conn.commit()
    cur.execute('SELECT * FROM ensaios WHERE id = ?', (ensaio_id,))
    ensaio = cur.fetchone()
    conn.close()
    return ensaio, pdf_path


@app.get('/laudo/{ensaio_id}/pdf')
def gerar_pdf(request: Request, ensaio_id: int):
    ensaio, pdf_path = get_or_build_pdf(request, ensaio_id)
    return FileResponse(str(pdf_path), media_type='application/pdf', filename=pdf_path.name)


@app.post('/laudo/{ensaio_id}/enviar-email')
def enviar_email_laudo(request: Request, ensaio_id: int, to: str = Form(...), subject: str = Form('')):
    user = require_role(request, ['admin', 'engenheiro'])
    ensaio, pdf_path = get_or_build_pdf(request, ensaio_id)
    settings = get_settings_map()
    smtp_host = settings.get('smtp_host', '').strip()
    smtp_user = settings.get('smtp_user', '').strip()
    smtp_password = settings.get('smtp_password', '')
    smtp_from = settings.get('smtp_from', '').strip() or smtp_user
    smtp_port = int(settings.get('smtp_port', '587') or '587')
    use_tls = settings.get('smtp_use_tls', '1') == '1'

    if not smtp_host or not smtp_from:
        return JSONResponse({'ok': False, 'mensagem': 'SMTP não configurado. Acesse Configurações para preencher host, usuário e remetente.'}, status_code=400)

    msg = EmailMessage()
    msg['From'] = smtp_from
    msg['To'] = to
    msg['Subject'] = subject or f'Laudo de Esclerometria - Ensaio #{ensaio_id}'
    msg.set_content(
        f'''Prezados,\n\nSegue o laudo de esclerometria referente ao ensaio #{ensaio_id}.\n\nCliente: {ensaio["cliente"]}\nObra: {ensaio["obra"]}\nStatus: {ensaio["status"]}\n\nAtenciosamente,\n{user["full_name"] or user["username"]}\nAXIAL Tecnologia para Construção Civil'''
    )
    with open(pdf_path, 'rb') as f:
        msg.add_attachment(f.read(), maintype='application', subtype='pdf', filename=pdf_path.name)

    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=20) as server:
            if use_tls:
                server.starttls()
            if smtp_user:
                server.login(smtp_user, smtp_password)
            server.send_message(msg)
    except Exception as e:
        return JSONResponse({'ok': False, 'mensagem': f'Falha ao enviar e-mail: {e}'}, status_code=500)

    conn = get_conn()
    cur = conn.cursor()
    cur.execute('UPDATE ensaios SET email_sent_at = ? WHERE id = ?', (datetime.now().strftime('%Y-%m-%d %H:%M'), ensaio_id))
    conn.commit()
    conn.close()
    return {'ok': True, 'mensagem': f'E-mail enviado para {to} com sucesso.'}


@app.get('/configuracoes', response_class=HTMLResponse)
def configuracoes_form(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)
    if user['role'] != 'admin':
        return RedirectResponse(url='/dashboard', status_code=303)
    settings = get_settings_map()
    return templates.TemplateResponse('configuracoes.html', {'request': request, 'user': user, 'role_labels': ROLE_LABELS, 'settings': settings})


@app.post('/configuracoes')
def salvar_configuracoes(
    request: Request,
    company_name: str = Form(...),
    cloud_provider: str = Form(...),
    cloud_base_path: str = Form(...),
    smtp_host: str = Form(''),
    smtp_port: str = Form('587'),
    smtp_user: str = Form(''),
    smtp_password: str = Form(''),
    smtp_from: str = Form(''),
    smtp_use_tls: Optional[str] = Form(None)
):
    require_role(request, ['admin'])
    settings = {
        'company_name': company_name.strip(),
        'cloud_provider': cloud_provider.strip(),
        'cloud_base_path': cloud_base_path.strip(),
        'smtp_host': smtp_host.strip(),
        'smtp_port': smtp_port.strip(),
        'smtp_user': smtp_user.strip(),
        'smtp_password': smtp_password,
        'smtp_from': smtp_from.strip(),
        'smtp_use_tls': '1' if smtp_use_tls else '0'
    }
    conn = get_conn()
    cur = conn.cursor()
    for k, v in settings.items():
        cur.execute('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', (k, v))
    conn.commit()
    conn.close()
    return RedirectResponse(url='/configuracoes?ok=1', status_code=303)


@app.get('/usuarios', response_class=HTMLResponse)
def usuarios_form(request: Request):
    user = get_current_user(request)
    if not user:
        return RedirectResponse(url='/', status_code=303)
    if user['role'] != 'admin':
        return RedirectResponse(url='/dashboard', status_code=303)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM users ORDER BY id')
    usuarios = cur.fetchall()
    conn.close()
    return templates.TemplateResponse('usuarios.html', {'request': request, 'user': user, 'role_labels': ROLE_LABELS, 'usuarios': usuarios})


@app.post('/usuarios')
def criar_usuario(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form(...),
    full_name: str = Form(''),
    email: str = Form('')
):
    require_role(request, ['admin'])
    if role not in ROLE_LABELS:
        return JSONResponse({'ok': False, 'mensagem': 'Perfil inválido.'}, status_code=400)
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (username, password_hash, role, full_name, email, signature_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (username.strip(), hash_password(password), role, full_name.strip(), email.strip(), '/static/signatures/signature_default.png', datetime.now().isoformat(timespec='seconds'))
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return JSONResponse({'ok': False, 'mensagem': 'Usuário já existe.'}, status_code=400)
    conn.close()
    return RedirectResponse(url='/usuarios', status_code=303)


@app.post('/usuarios/{user_id}/toggle')
def toggle_usuario(request: Request, user_id: int):
    require_role(request, ['admin'])
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT is_active FROM users WHERE id = ?', (user_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail='Usuário não encontrado')
    cur.execute('UPDATE users SET is_active = ? WHERE id = ?', (0 if row['is_active'] else 1, user_id))
    conn.commit()
    conn.close()
    return RedirectResponse(url='/usuarios', status_code=303)


@app.get('/api/ensaios')
def api_ensaios(request: Request):
    require_login(request)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('SELECT * FROM ensaios ORDER BY id DESC')
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


@app.post('/perfil/assinatura')
async def upload_assinatura(request: Request, assinatura: UploadFile = File(...)):
    user = require_login(request)
    suffix = Path(assinatura.filename).suffix.lower() or '.png'
    if suffix not in ['.png', '.jpg', '.jpeg']:
        return JSONResponse({'ok': False, 'mensagem': 'Formato inválido. Use PNG ou JPG.'}, status_code=400)

    file_name = f'sign_{user["username"]}{suffix}'
    dest = SIGNATURES_DIR / file_name
    with dest.open('wb') as f:
        shutil.copyfileobj(assinatura.file, f)

    public_path = f'/static/signatures/{file_name}'
    conn = get_conn()
    cur = conn.cursor()
    cur.execute('UPDATE users SET signature_path = ? WHERE id = ?', (public_path, user['id']))
    conn.commit()
    conn.close()
    return {'ok': True, 'mensagem': 'Assinatura atualizada com sucesso.', 'signature_path': public_path}
