# AXIAL Sistema Web V3

Versão 3 com:
- geração de PDF
- QR Code
- assinatura eletrônica visual
- envio por e-mail via SMTP
- armazenamento em Google Drive/OneDrive por pasta sincronizada
- controle real de usuários e perfis

## Requisitos
- Python 3.10+
- pip

## Instalação
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Acesso
Abra:
`http://127.0.0.1:8000`

## Usuários iniciais
- admin / 1234
- engenharia / 1234
- tecnico / 1234

## Perfis
- admin: acesso total
- engenheiro: aferição, ensaios, exportação e envio por e-mail
- técnico: lançamento de ensaios e consulta

## Configuração de armazenamento
No menu **Configurações**, ajuste:
- Provedor: `google_drive`, `onedrive` ou `local`
- Caminho base: a pasta sincronizada local do provedor

Exemplos:
- Google Drive: `C:\Users\SEU_USUARIO\Google Drive\AXIAL\LAUDOS`
- OneDrive: `C:\Users\SEU_USUARIO\OneDrive\AXIAL\LAUDOS`

Os PDFs continuam sendo gerados em `exports/` e também são copiados para a pasta configurada.

## Configuração de e-mail
No menu **Configurações**, informe:
- SMTP host
- SMTP port
- SMTP user
- SMTP password
- SMTP from
- TLS

Sem SMTP configurado, o botão de envio mostra uma mensagem orientando a configurar.

## Testes rápidos sugeridos
1. Faça login como `admin`
2. Cadastre uma aferição
3. Cadastre um ensaio
4. Abra o laudo e gere o PDF
5. Configure uma pasta sincronizada e gere o PDF novamente
6. Configure SMTP e teste o envio

## Observação
A assinatura gerada no laudo é eletrônica visual com hash SHA-256 e não substitui certificado ICP-Brasil.
